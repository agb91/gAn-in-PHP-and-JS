<!DOCTYPE html>
<html>
    <head>
        <title>gAn web interface</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <script src="JS/jquery.js"></script>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
        <link href="CSS/showOneImage.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
        <script src="bootstrap/js/bootstrap.js"> </script>
        <script src="JSROOTlibraries/scripts/JSRootCore.js" type="text/javascript"></script>
        
    </head>
    <body>
        <div class="showImageGeneral">
            <div class="fixedUpLeft">
                <?php
                    include "PHP/genericFunctions.php";
		    include "Globals.php";
                ?>
            </div>
            <?php
            ?>
            <div class="row">
               <div class= "col-xs-12">
                    <div id="place1" style="width: 100%"></div><br>
                </div>
            </div>
       </div>
    </body>
</html>
