/*! \brief Just for skip "show one image" page
 *
 * the only goal of this script is to skip the page Show One Image and go directly to the root-like image 
 * page
 */

//alert("alive");
$("#showRootLikeImage").click();