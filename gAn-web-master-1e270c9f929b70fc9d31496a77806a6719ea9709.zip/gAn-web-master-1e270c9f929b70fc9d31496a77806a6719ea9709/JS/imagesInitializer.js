
//is a good idea to initialize some values when the page is starting 
$( document ).ready(function() {
    $("#labelImagesLayout").text("Now: Layout Images Vertical");
    $("#labelImagesGroup").text("Group shown now: Mimito");

    $("#groupButton1").click();
});