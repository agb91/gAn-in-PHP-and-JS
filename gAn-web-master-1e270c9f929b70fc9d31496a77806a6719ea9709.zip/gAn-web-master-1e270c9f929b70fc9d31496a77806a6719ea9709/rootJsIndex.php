<!DOCTYPE html>
<html>
    <head>
        <title>gAn web interface</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <script src="JS/jquery.js"></script>
        <script src="JS/rootJsIndex.js"></script>
        <script src="JSROOTlibraries/JsRoot451/scripts/JSRootCore.js?2d&onload=startGUI" type="text/javascript"></script>
    </head>
    <body>    
        <div id="object_draw" style="width: 800px; height:600px"></div>
        <div id="object_draw2" style="width: 800px; height:600px"></div>
        <div id="object_draw3" style="width: 800px; height:600px"></div>
        <div id="object_draw4" style="width: 800px; height:600px"></div>
    </body>
</html>