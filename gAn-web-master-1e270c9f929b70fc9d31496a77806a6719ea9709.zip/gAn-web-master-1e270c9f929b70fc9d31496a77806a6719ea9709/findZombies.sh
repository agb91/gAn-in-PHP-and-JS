ps -aux | grep gAnShStarted | grep www-data
