#include <cstddef>
#include <stdio.h>
#include <signal.h>

int main() {
	double a=0;
	while(true)
	{
		a++;
	}
	return -1;
}
