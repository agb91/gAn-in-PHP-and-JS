kill -9 $1
